Wow! A huge congratulations to you and the team on a successful project. If you're reading this task, that means you've concluded your project.


To formally complete the project, please go back to the Project Board overview, click on the **More** Button in the top right corner and choose **Complete Mission**.

![](images/complete_mission.png)


After completing the mission, you'll get a dialog with a small survey. We'd love to hear your feedback on the entire project so that we may continue to improve our offering to you.

 

**See you on your next mission!**

